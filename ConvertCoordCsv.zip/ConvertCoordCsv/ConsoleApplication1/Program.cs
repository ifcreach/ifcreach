﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using ClipperLib;

namespace ConsoleApplication1
{
    class Program
    {
        private static void ParseSimple()
        {
            Dictionary<string, List<Tuple<string, string>>> d =
                   new Dictionary<string, List<Tuple<string, string>>>();
            using (var fi = new StreamReader(@"C:\Users\rmax\Downloads\countries_4.txt"))
            {

                var line = "";
                while ((line = fi.ReadLine()) != null)
                {
                    var arr = line.Split(',');
                    var regionName = arr[0].Trim();
                    var list = new List<Tuple<string, string>>();
                    for (int i = 1; i < arr.Length; i++)
                    {
                        var coords = arr[i].Trim().Split(' ');
                        list.Add(new Tuple<string, string>(coords[0], coords[1]));

                    }

                    d.Add(regionName, list);
                }
            }
            using (var fw = new StreamWriter(@"C:\Temp\kml\region_boundaries.csv"))
            {
                fw.WriteLine("REGION, VERTEX TYPE, LATITUDE, LONGITUDE, POINTORDER, POLYGON NUMBER");
                var polyNumber = 0;
                foreach (var key in d.Keys)
                {
                    polyNumber++;
                    var order = 0;
                    for (int i = 0; i < d[key].Count; i++)
                    {
                        fw.WriteLine(String.Format("{0}, {1}, {2}, {3}, {4}, {5}", key, i == 0 ? "Start" : (i == d[key].Count - 1 ? "End" : "Internal"), d[key][i].Item1, d[key][i].Item2, ++order, polyNumber));
                    }
                }
            }
        }

        private static List<Tuple<string, string, string, string, int, int>> GetCoordinates()
        {
            var list = new List<Tuple<string, string, string, string, int, int>>();
            using (var fi = new StreamReader(@"C:\Users\rmax\Downloads\countries_new.txt"))
            {

                var line = "";
                var polyNum = 0;
                while ((line = fi.ReadLine()) != null)
                {
                    if (line == "") continue;
                    var arr = line.Split(new string[] { "MULTIPOLYGON", "POLYGON" }, StringSplitOptions.RemoveEmptyEntries);
                    var regionName = arr[0].Trim(",(".ToCharArray()).Trim();

                    for (int i = 1; i < arr.Count(); i++)
                    {
                        if (arr[i].Trim().StartsWith("EMPTY")) continue;
                        var polygons = arr[i].Trim("(),".ToCharArray()).Split(new[] { ")),((" }, StringSplitOptions.RemoveEmptyEntries);
                        for (int j = 0; j < polygons.Length; j++)
                        {
                            polyNum++;
                            var polygon = polygons[j];
                            var coords = polygon.Split(',');
                            var ord = 0;
                            for (int k = 0; k < coords.Length; k++)
                            {
                                var coord = coords[k];
                                var latLon = coord.Split(' ');
                                list.Add(new Tuple<string, string, string, string, int, int>(regionName, k == 0 ? "Start" : (k == coords.Length - 1 ? "End" : "Internal"), latLon[1], latLon[0], ++ord, polyNum));
                            }

                        }
                    }

                }
            }

            return list;
        }

        private static List<Tuple<string, string, double, double, int, int>> Normalize(List<Tuple<string, string, string, string, int, int>> list, int precision)
        {
            var retVal = new List<Tuple<string, string, double, double, int, int>>();
            foreach (var row in list)
            {
                var lat = Double.Parse(row.Item3.Trim("()".ToCharArray()));
                var lon = Double.Parse(row.Item4.Trim("()".ToCharArray()));
                lat = (lat + 90)*Math.Pow(10, precision);
                lon = (lon + 180)*Math.Pow(10, precision);
                retVal.Add(new Tuple<string, string, double, double, int, int>(row.Item1, row.Item2, lat, lon, row.Item5, row.Item6));
            }

            return retVal;
        }

        private static List<Tuple<string, string, double, double, int, int>> Denormalize(List<Tuple<string, string, double, double, int, int>> list, int precision)
        {
            var retVal = new List<Tuple<string, string, double, double, int, int>>();
            foreach (var row in list)
            {
                var lat = row.Item3; // Math.Round(Double.Parse(row.Item3.Trim("()".ToCharArray())), 4);
                var lon = row.Item4; //Math.Round(Double.Parse(row.Item4.Trim("()".ToCharArray())), 4);
                lat = lat / Math.Pow(10, precision) - 90;
                lon = lon / Math.Pow(10, precision) - 180;
                retVal.Add(new Tuple<string, string, double, double, int, int>(row.Item1, row.Item2, lat, lon, row.Item5, row.Item6));
            }

            return retVal;
        }
        

        private static void CreateOutline()
        {
            var precision = 1;
            var list = GetCoordinates();
            var normList = Normalize(list, precision);
            Clip(normList);
            //CreateBitmap(normList);
            var denormList = Denormalize(normList, precision);
        }

        private static void Clip(List<Tuple<string, string, double, double, int, int>> list)
        {
            var clipper = new Clipper();
            
            var polygons = list.GroupBy(t => t.Item6);
            foreach (var polygon in polygons)
            {
                //if (polygon.Key <= 540)
                {
                    var points = polygon.Select(g => new IntPoint(g.Item4, g.Item3)).ToList();
                    clipper.AddPath(points, PolyType.ptSubject, true);
                    //graphics.FillPolygon(Brushes.Red, points);
                }
            }

            var solution = new List<List<IntPoint>>();
            var result = clipper.Execute(ClipType.ctUnion, solution, PolyFillType.pftNonZero, PolyFillType.pftNonZero);

            var maxLat = 0d;
            var minLat = Double.MaxValue;
            var maxLon = 0d;
            var minLon = Double.MaxValue;
            foreach (var tuple in list)
            {
                if (maxLat < tuple.Item3) maxLat = tuple.Item3;
                if (minLat > tuple.Item3) minLat = tuple.Item3;
                if (maxLon < tuple.Item4) maxLon = tuple.Item4;
                if (minLon > tuple.Item4) minLon = tuple.Item4;
            }

            var right = Convert.ToInt32(Math.Ceiling(maxLon));
            var top = Convert.ToInt32(Math.Ceiling(maxLat));
            var original = new Bitmap(right, top);
            using (var graphics = Graphics.FromImage(original))
            {
                foreach (var polygon in solution)
                {
                    var points = polygon.Select(g => new PointF((float)g.X, (float)g.Y)).ToArray();
                    graphics.FillPolygon(Brushes.Red, points);
                    
                }

            }
            original.Save(@"C:\temp\testimage_clip.png", ImageFormat.Png);

        }

        private static void CreateBitmap(List<Tuple<string, string, double, double, int, int>> list)
        {
            var maxLat = 0d;
            var minLat = Double.MaxValue;
            var maxLon = 0d;
            var minLon = Double.MaxValue;
            foreach (var tuple in list)
            {
                if (maxLat < tuple.Item3) maxLat = tuple.Item3;
                if (minLat > tuple.Item3) minLat = tuple.Item3;
                if (maxLon < tuple.Item4) maxLon = tuple.Item4;
                if (minLon > tuple.Item4) minLon = tuple.Item4;
            }

            var right = Convert.ToInt32(Math.Ceiling(maxLon));
            var top = Convert.ToInt32(Math.Ceiling(maxLat));
            var original = new Bitmap(right, top);
            var mask = new Bitmap(right, top);
            using (var mg = Graphics.FromImage(mask))
            {
                mg.FillRectangle(Brushes.Green, 0f, 0f, right, top);
            }
            
            using (var graphics = Graphics.FromImage(original))
            {
                var polygons = list.GroupBy(t => t.Item6);
                foreach (var polygon in polygons)
                {
                    if (polygon.Key <= 540)
                    {
                        var points = polygon.Select(g => new PointF((float) g.Item4, (float) g.Item3)).ToArray();
                        graphics.FillPolygon(Brushes.Red, points);
                    }
                }
                
            }
            for (int i = 0; i < original.Width; i++)
            {
                for (int j = 0; j < original.Height; j++)
                {
                    if (original.GetPixel(i, j).A == Color.Transparent.A)
                    {
                        mask.SetPixel(i, j, Color.Transparent);
                    }
                }
            }
            var outBitmap = new Bitmap(right, top);
            using (var graphics = Graphics.FromImage(outBitmap))
            {
                graphics.DrawImage(mask, 0, 0);
                graphics.DrawImage(original, 0, 0);
            }
            outBitmap.Save(@"C:\temp\testimage.png", ImageFormat.Png);
        }

        private static void ParseComplex()
        {
            var list = GetCoordinates();

            using (var fw = new StreamWriter(@"C:\Temp\kml\region_boundaries.csv"))
            {
                fw.WriteLine("Region, VERTEX TYPE, LATITUDE, LONGITUDE, POINTORDER, POLYGON NUMBER");
                var polyNumber = 0;
                foreach (var l in list)
                {
                    if (l.Item1 != "Antarctica" && l.Item1 != "North America")
                        fw.WriteLine("{0}, {1}, {2}, {3}, {4}, {5}", l.Item1, l.Item2, l.Item3.Trim("()".ToCharArray()), l.Item4.Trim("()".ToCharArray()), l.Item5, l.Item6);
                }
            }
        }

        static void Main(string[] args)
        {
            ParseComplex();
            //CreateOutline();
        }
    }
}
